package za.co.mdantsanemove

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Teal = Color(0xFF0F766E)
private val Navy = Color(0xFF0B292E)
private val Pale = Color(0xFFF3F7F7)

data class Journey(
    val id: Int, val mode: String, val from: String, val to: String,
    val duration: String, val fare: String, val schedule: String, val note: String
)

private val sampleJourneys = listOf(
    Journey(1, "Bus", "Mdantsane", "East London CBD", "Check operator", "Check operator",
        "No verified departure time", "Confirm the bus route, stop and departure time with the operator."),
    Journey(2, "Bus", "Mdantsane", "Vincent", "Check operator", "Check operator",
        "No verified departure time", "Example search corridor. Confirm whether a direct service operates."),
    Journey(3, "Train", "Mdantsane", "East London", "Check operator", "Check operator",
        "No verified departure time", "Passenger train service and station stops must be confirmed with the rail operator."),
    Journey(4, "Bus", "East London CBD", "Mdantsane", "Check operator", "Check operator",
        "No verified departure time", "Return journey example. Verify the correct stop and current timetable.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MdantsaneMoveApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MdantsaneMoveApp() {
    var tab by remember { mutableStateOf("Home") }
    var origin by remember { mutableStateOf("Mdantsane") }
    var destination by remember { mutableStateOf("East London CBD") }
    var mode by remember { mutableStateOf("All") }
    var searched by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Journey?>(null) }
    var savedIds by remember { mutableStateOf(setOf<Int>()) }

    val journeys = sampleJourneys.filter { j ->
        (mode == "All" || j.mode == mode) &&
        (!searched || ((j.from.equals(origin, true) && j.to.equals(destination, true)) ||
            (j.from.equals(destination, true) && j.to.equals(origin, true))))
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Navy, background = Pale)) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Text("Mdantsane Move", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("BUSES & TRAINS  •  MDANTSANE + EAST LONDON", color = Color(0xFFB8F3DC), fontSize = 11.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == "Home", onClick = { tab = "Home"; selected = null },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == "Routes", onClick = { tab = "Routes"; selected = null },
                        icon = { Icon(Icons.Default.Route, null) }, label = { Text("Routes") })
                    NavigationBarItem(selected = tab == "Saved", onClick = { tab = "Saved"; selected = null },
                        icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Saved") })
                    NavigationBarItem(selected = tab == "Alerts", onClick = { tab = "Alerts"; selected = null },
                        icon = { Icon(Icons.Default.Notifications, null) }, label = { Text("Alerts") })
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (selected != null) {
                    JourneyDetail(selected!!, savedIds.contains(selected!!.id), {
                        savedIds = if (savedIds.contains(selected!!.id)) savedIds - selected!!.id else savedIds + selected!!.id
                    }, { selected = null })
                } else when (tab) {
                    "Home" -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Text("Where are you going today?", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
                            Text("Search bus and train journeys.", color = Color.Gray, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("FROM", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                    PlaceField(origin, { origin = it }, listOf("Mdantsane", "East London CBD", "East London Station", "Vincent", "Berlin"))
                                    Text("TO", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                    PlaceField(destination, { destination = it }, listOf("East London CBD", "Mdantsane", "East London Station", "Vincent", "Berlin"))
                                    Button(onClick = { searched = true; mode = "All" }, modifier = Modifier.fillMaxWidth()) {
                                        Text("Find transport")
                                    }
                                    TextButton(onClick = { val x = origin; origin = destination; destination = x }) {
                                        Text("⇅ Swap locations")
                                    }
                                }
                            }
                        }
                        item { Text("Transport type", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("All", "Bus", "Train").forEach { m ->
                                    FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m) })
                                }
                            }
                        }
                        item { Text(if (searched) "Search results" else "Journey examples", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                        items(journeys) { j -> JourneyCard(j, savedIds.contains(j.id), { selected = j }, {
                            savedIds = if (savedIds.contains(j.id)) savedIds - j.id else savedIds + j.id
                        }) }
                        item { DemoNotice() }
                    }
                    "Routes" -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("Explore routes", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("All", "Bus", "Train").forEach { m -> FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m) }) }
                        } }
                        items(sampleJourneys.filter { mode == "All" || it.mode == mode }) { j ->
                            JourneyCard(j, savedIds.contains(j.id), { selected = j }, { savedIds = if (savedIds.contains(j.id)) savedIds - j.id else savedIds + j.id })
                        }
                        item { DemoNotice() }
                    }
                    "Saved" -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("Saved journeys", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                        if (savedIds.isEmpty()) item { Text("No saved journeys yet. Tap the heart on a journey to save it.", color = Color.Gray) }
                        items(sampleJourneys.filter { savedIds.contains(it.id) }) { j ->
                            JourneyCard(j, true, { selected = j }, { savedIds = savedIds - j.id })
                        }
                    }
                    else -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Service alerts", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Live updates are not connected", fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Check with the bus or rail operator for cancellations, delays and timetable changes. This starter app does not receive live service alerts.")
                            }
                        }
                        DemoNotice()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaceField(value: String, onValue: (String) -> Unit, options: List<String>) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.menuAnchor().fillMaxWidth(),
            singleLine = true, label = { Text("Choose place") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onValue(option); expanded = false }) }
        }
    }
}

@Composable
fun JourneyCard(j: Journey, saved: Boolean, onOpen: () -> Unit, onSave: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(17.dp),
        modifier = Modifier.fillMaxWidth().clickable { onOpen() }) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (j.mode == "Bus") "🚌  BUS" else "🚆  TRAIN", color = Teal, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = onSave) { Icon(if (saved) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Save journey", tint = Teal) }
            }
            Text("${j.from}  →  ${j.to}", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(6.dp))
            Text("Departure: ${j.schedule}", color = Color.Gray, fontSize = 12.sp)
            Text("Duration: ${j.duration}     •     Fare: ${j.fare}", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
            Text("View journey details →", color = Teal, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
        }
    }
}

@Composable
fun JourneyDetail(j: Journey, saved: Boolean, onSave: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("← Back", color = Teal, modifier = Modifier.clickable { onBack() }.padding(bottom = 18.dp))
        Text(if (j.mode == "Bus") "🚌 Bus journey" else "🚆 Train journey", color = Teal, fontWeight = FontWeight.Bold)
        Text("${j.from} to ${j.to}", fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp, bottom = 14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Journey information", fontWeight = FontWeight.Bold)
                Text("Departure: ${j.schedule}")
                Text("Travel time: ${j.duration}")
                Text("Fare: ${j.fare}")
                HorizontalDivider()
                Text(j.note)
            }
        }
        Spacer(Modifier.height(12.dp))
        DemoNotice()
        Spacer(Modifier.height(12.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text(if (saved) "♥ Saved" else "♡ Save journey") }
    }
}

@Composable
fun DemoNotice() {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)), shape = RoundedCornerShape(13.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text("Important: timetable not verified", fontWeight = FontWeight.Bold, color = Color(0xFF9A3412))
            Spacer(Modifier.height(5.dp))
            Text("This starter app does not contain confirmed live schedules, fares or service status. Check with the transport operator before travelling.", color = Color(0xFF7C2D12), fontSize = 12.sp)
        }
    }
}
