# Mdantsane Move — Android starter project

A native Android app starter for bus and train passenger journeys in Mdantsane and East London.

## Included
- Native Android UI built with Kotlin and Jetpack Compose
- Home search with selectable origin and destination
- Bus/train filters
- Journey details
- Saved journeys (kept in memory while the app is running)
- Service-alert information screen
- Clear warnings that schedules and fares are not verified

## Important data note
No live timetable, fare feed, route map, or alert service is connected. Route entries are illustrative search examples and must not be treated as confirmation that a service operates. Verify local operator information before publishing.

## Build an APK
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `MdantsaneMoveAndroid` folder.
4. Allow Gradle sync to finish. Use JDK 17 if prompted.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Press **Run** to install the app on the device.
7. To create an installable APK, select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. Android Studio will show the APK location. For sharing beyond testing, create a signed build using **Build → Generate Signed Bundle / APK**.

## Before a public launch
- Replace the example route list with verified operator schedules and stops.
- Confirm passenger train availability and stations directly with the rail operator.
- Add a trusted data source/API for timetables and service notices.
- Persist saved routes with a local database.
- Test on multiple Android screen sizes and with passengers.
- Add privacy policy and appropriate store listing details.

## Package details
- Application ID: `za.co.mdantsanemove`
- Version: `1.0`
- Minimum Android version: Android 8.0 (API 26)
